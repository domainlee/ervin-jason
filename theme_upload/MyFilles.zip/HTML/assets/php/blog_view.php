<?php
$data = $_POST;
// List post
$post = array(
    '1' => array(
        'id' => '1',
        'title' => 'Facebook Said to Consider Banning Political Ads',
        'date' => 'June 2, 2022',
        'image' => 'assets/images/leone-venter-pVt9j3iWtPM-unsplash.jpg',
        'category' => 'Life',
        'content' => '<div class="editor-content editor-content__dropcap">
                        <p>Cu duo antiopam platonem electram. Dicam tibique an qui, ius ut integre rationibus, ad eos facilisi voluptatibus. Has et impetus labitur, ea duo laoreet sententiae. Hendrerit efficiendi voluptatibus has ea, corrumpit democritum eu sea, eum ex vero veniam. Dicunt ornatus laoreet te eam, vix eu zril epicuri deseruisse. <a href="#">Lorem ipsum</a> dolor sit amet, eu postulant principes quo, an melius scaevola quo. Pri no malorum omittantur, nusquam conclusionemque an sea. Usu amet minim intellegat ut. Ut putant latine petentium sea, sit alii meliore eu.</p>
                        <p>Vix et labitur epicuri dissentiunt, habemus complectitur an qui, ei qui hinc falli aperiam. Te <a href="#">eos altera</a> eruditi, in cum adipisci sadipscing, modo numquam recusabo cu eum. Augue putant <a href="#">dissentiunt</a> at qui. At pro accusata prodesset vituperatoribus, vel feugait corpora suscipit ut, paulo equidem dissentias ei his.</p>
                        <p>Pro in ridens possit referrentur, ne odio tibique duo. Lorem persecuti scribentur ut est. Eu novum tation persius nec. Sed soluta primis splendide ei. Vis ei tritani alterum petentium, usu sint intellegat ne. Sed in tota nobis prompta, noluisse delicatissimi at ius. <a rel="noreferrer noopener" href="#" target="_blank">Veri placerat</a> mel in, paulo persius omittantur in mei, putant molestie suscipiantur vis ad. Ut mel tollit tacimates suscipiantur, sit audire recusabo philosophia ad, mei amet animal pertinax eu. Mea ipsum offendit appetere eu, justo ubique fierent vis ne. Probo omnesque has ex. Pro no lorem temporibus ullamcorper, no qui democritum consectetuer, habemus pericula eu sit.</p>
                        <figure class="alignleft">
                            <img src="assets/images/amelie-mourichon-wusOJ-2uY6w-unsplash.jpg" alt="">
                            <figcaption>Cu duo antiopam platonem electram</figcaption>
                        </figure>
                        <p>Pro in ridens possit referrentur, ne odio tibique duo. Lorem persecuti scribentur ut est. Eu novum tation persius nec. Sed soluta primis splendide ei. Vis ei tritani alterum petentium, usu sint intellegat ne. Sed in tota nobis prompta, noluisse delicatissimi at ius. <a rel="noreferrer noopener" href="#" target="_blank">Veri placerat</a> mel in, paulo persius omittantur in mei, putant molestie suscipiantur vis ad. Ut mel tollit tacimates suscipiantur, sit audire recusabo philosophia ad, mei amet animal pertinax eu. Mea ipsum offendit appetere eu, justo ubique fierent vis ne. Probo omnesque has ex. Pro no lorem temporibus ullamcorper, no qui democritum consectetuer, habemus pericula eu sit.</p>
                        <p class="has-drop-cap">Has no velit ullamcorper, tale aliquando constituto ei sea, sit iisque facilisi ei. Ad quo possit disputationi. Eam invenire laboramus constituam ex, vel dolore antiopam ex, te pro tota sonet noluisse. Menandri molestiae eum an, pri ut ludus deterruisset delicatissimi. At noster iriure nec, et vix dico graecis.</p>
                        <p>Vel posse suavitate ne. Nam ut enim verear latine, et latine aeterno menandri vel. Fugit habemus posidonium te est, cu his primis tincidunt inciderint. At aeque corpora nam, saepe perfecto at eos. Invidunt reprimique ius an.</p>
                        <blockquote><p>I am enough of an artist to draw freely upon my imagination. Imagination is more important than knowledge. Knowledge is limited. Imagination encircles the world</p></blockquote>
                        <figure class="aligncenter">
                            <img src="assets/images/ilya-pavlov-OqtafYT5kTw-unsplash.jpg" alt="">
                            <figcaption>Align center</figcaption>
                        </figure>
                        <h2>Ordered List</h2>
                        <hr>
                        <p>Vix et labitur epicuri dissentiunt, habemus complectitur an qui, ei qui hinc falli aperiam. Te <a href="#">eos altera</a> eruditi, in cum adipisci sadipscing, modo numquam recusabo cu eum. Augue putant <a href="#">dissentiunt</a> at qui. At pro accusata prodesset vituperatoribus, vel feugait corpora suscipit ut, paulo equidem dissentias ei his.</p>
                        <ul>
                            <li>Aliquam erat volutpat</li>
                            <li>Lacinia scelerisque lacinia quis</li>
                            <li>Consectetuer adipiscing elit</li>
                            <li>Magnis dis parturient montes</li>
                        </ul>
                        <p>Pro in ridens possit referrentur, ne odio tibique duo. Lorem persecuti scribentur ut est. Eu novum tation persius nec. Sed soluta primis splendide ei. Vis ei tritani alterum petentium, usu sint intellegat ne. Sed in tota nobis prompta, noluisse delicatissimi at ius. <a rel="noreferrer noopener" href="#" target="_blank">Veri placerat</a> mel in, paulo persius omittantur in mei, putant molestie suscipiantur vis ad. Ut mel tollit tacimates suscipiantur, sit audire recusabo philosophia ad, mei amet animal pertinax eu. Mea ipsum offendit appetere eu, justo ubique fierent vis ne. Probo omnesque has ex. Pro no lorem temporibus ullamcorper, no qui democritum consectetuer, habemus pericula eu sit.</p>
                        <h2>Ordered List Number</h2>
                        <p>Vix et labitur epicuri dissentiunt, habemus complectitur an qui, ei qui hinc falli aperiam. Te <a href="#">eos altera</a> eruditi, in cum adipisci sadipscing, modo numquam recusabo cu eum. Augue putant <a href="#">dissentiunt</a> at qui. At pro accusata prodesset vituperatoribus, vel feugait corpora suscipit ut, paulo equidem dissentias ei his.</p>
                        <ol>
                            <li>Commodo ligula eget dolor</li>
                            <li>Magnis dis parturient montes</li>
                            <li>Pellentesque eu pretium</li>
                            <li>Donec quam felis</li>
                            <li>Lorem ipsum dolor sit amet</li>
                        </ol>
                        <p>Pro in ridens possit referrentur, ne odio tibique duo. Lorem persecuti scribentur ut est. Eu novum tation persius nec. Sed soluta primis splendide ei. Vis ei tritani alterum petentium, usu sint intellegat ne. Sed in tota nobis prompta, noluisse delicatissimi at ius. <a rel="noreferrer noopener" href="#" target="_blank">Veri placerat</a> mel in, paulo persius omittantur in mei, putant molestie suscipiantur vis ad. Ut mel tollit tacimates suscipiantur, sit audire recusabo philosophia ad, mei amet animal pertinax eu. Mea ipsum offendit appetere eu, justo ubique fierent vis ne. Probo omnesque has ex. Pro no lorem temporibus ullamcorper, no qui democritum consectetuer, habemus pericula eu sit.</p>
                        <p>Cu duo antiopam platonem electram. Dicam tibique an qui, ius ut integre rationibus, ad eos facilisi voluptatibus. Has et impetus labitur, ea duo laoreet sententiae. Hendrerit efficiendi voluptatibus has ea, corrumpit democritum eu sea, eum ex vero veniam. Dicunt ornatus laoreet te eam, vix eu zril epicuri deseruisse. <a href="#">Lorem ipsum</a> dolor sit amet, eu postulant principes quo, an melius scaevola quo. Pri no malorum omittantur, nusquam conclusionemque an sea. Usu amet minim intellegat ut. Ut putant latine petentium sea, sit alii meliore eu.</p>
                    </div>

                    <div class="editor-content editor-content__col-two">
                        <p>Cu duo antiopam platonem electram. Dicam tibique an qui, ius ut integre rationibus, ad eos facilisi voluptatibus. Has et impetus labitur, ea duo laoreet sententiae. Hendrerit efficiendi voluptatibus has ea, corrumpit democritum eu sea, eum ex vero veniam. Dicunt ornatus laoreet te eam, vix eu zril epicuri deseruisse. <a href="#">Lorem ipsum</a> dolor sit amet, eu postulant principes quo, an melius scaevola quo. Pri no malorum omittantur, nusquam conclusionemque an sea. Usu amet minim intellegat ut. Ut putant latine petentium sea, sit alii meliore eu.</p>
                        <figure class="alignright">
                            <img src="assets/images/jazmin-quaynor-8ioenvmof-I-unsplash.jpg" alt="">
                            <figcaption>Align right</figcaption>
                        </figure>
                        <p>Pro in ridens possit referrentur, ne odio tibique duo. Lorem persecuti scribentur ut est. Eu novum tation persius nec. Sed soluta primis splendide ei. Vis ei tritani alterum petentium, usu sint intellegat ne. Sed in tota nobis prompta, noluisse delicatissimi at ius. <a rel="noreferrer noopener" href="#" target="_blank">Veri placerat</a> mel in, paulo persius omittantur in mei, putant molestie suscipiantur vis ad. Ut mel tollit tacimates suscipiantur, sit audire recusabo philosophia ad, mei amet animal pertinax eu. Mea ipsum offendit appetere eu, justo ubique fierent vis ne. Probo omnesque has ex. Pro no lorem temporibus ullamcorper, no qui democritum consectetuer, habemus pericula eu sit.</p>
                        <figure class="alignleft">
                            <img src="assets/images/lum3n--RBuQ2PK_L8-unsplash.jpg" alt="">
                            <figcaption>Align left</figcaption>
                        </figure>
                        <p class="has-drop-cap">Has no velit ullamcorper, tale aliquando constituto ei sea, sit iisque facilisi ei. Ad quo possit disputationi. Eam invenire laboramus constituam ex, vel dolore antiopam ex, te pro tota sonet noluisse. Menandri molestiae eum an, pri ut ludus deterruisset delicatissimi. At noster iriure nec, et vix dico graecis.</p>
                        <p>Vel posse suavitate ne. Nam ut enim verear latine, et latine aeterno menandri vel. Fugit habemus posidonium te est, cu his primis tincidunt inciderint. At aeque corpora nam, saepe perfecto at eos. Invidunt reprimique ius an.</p>
                        <blockquote><p>I am enough of an artist to draw freely upon my imagination. Imagination is more important than knowledge. Knowledge is limited. Imagination encircles the world</p></blockquote>
                        <p>Vix et labitur epicuri dissentiunt, habemus complectitur an qui, ei qui hinc falli aperiam. Te <a href="#">eos altera</a> eruditi, in cum adipisci sadipscing, modo numquam recusabo cu eum. Augue putant <a href="#">dissentiunt</a> at qui. At pro accusata prodesset vituperatoribus, vel feugait corpora suscipit ut, paulo equidem dissentias ei his.</p>
                        <p>Pro in ridens possit referrentur, ne odio tibique duo. Lorem persecuti scribentur ut est. Eu novum tation persius nec. Sed soluta primis splendide ei. Vis ei tritani alterum petentium, usu sint intellegat ne. Sed in tota nobis prompta, noluisse delicatissimi at ius. <a rel="noreferrer noopener" href="#" target="_blank">Veri placerat</a> mel in, paulo persius omittantur in mei, putant molestie suscipiantur vis ad. Ut mel tollit tacimates suscipiantur, sit audire recusabo philosophia ad, mei amet animal pertinax eu. Mea ipsum offendit appetere eu, justo ubique fierent vis ne. Probo omnesque has ex. Pro no lorem temporibus ullamcorper, no qui democritum consectetuer, habemus pericula eu sit.</p>
                        <p>Cu duo antiopam platonem electram. Dicam tibique an qui, ius ut integre rationibus, ad eos facilisi voluptatibus. Has et impetus labitur, ea duo laoreet sententiae. Hendrerit efficiendi voluptatibus has ea, corrumpit democritum eu sea, eum ex vero veniam. Dicunt ornatus laoreet te eam, vix eu zril epicuri deseruisse. <a href="#">Lorem ipsum</a> dolor sit amet, eu postulant principes quo, an melius scaevola quo. Pri no malorum omittantur, nusquam conclusionemque an sea. Usu amet minim intellegat ut. Ut putant latine petentium sea, sit alii meliore eu.</p>
                    </div>'
    ),
    '2' => array(
        'id' => '2',
        'title' => 'Facebook Said to Consider Banning Political Ads',
        'date' => 'June 2, 2022',
        'image' => 'assets/images/jazmin-quaynor-8ioenvmof-I-unsplash.jpg',
        'category' => 'Travel',
        'content' => '<div class="editor-content editor-content__dropcap">
                        <p>Cu duo antiopam platonem electram. Dicam tibique an qui, ius ut integre rationibus, ad eos facilisi voluptatibus. Has et impetus labitur, ea duo laoreet sententiae. Hendrerit efficiendi voluptatibus has ea, corrumpit democritum eu sea, eum ex vero veniam. Dicunt ornatus laoreet te eam, vix eu zril epicuri deseruisse. <a href="#">Lorem ipsum</a> dolor sit amet, eu postulant principes quo, an melius scaevola quo. Pri no malorum omittantur, nusquam conclusionemque an sea. Usu amet minim intellegat ut. Ut putant latine petentium sea, sit alii meliore eu.</p>
                        <p>Vix et labitur epicuri dissentiunt, habemus complectitur an qui, ei qui hinc falli aperiam. Te <a href="#">eos altera</a> eruditi, in cum adipisci sadipscing, modo numquam recusabo cu eum. Augue putant <a href="#">dissentiunt</a> at qui. At pro accusata prodesset vituperatoribus, vel feugait corpora suscipit ut, paulo equidem dissentias ei his.</p>
                        <p>Pro in ridens possit referrentur, ne odio tibique duo. Lorem persecuti scribentur ut est. Eu novum tation persius nec. Sed soluta primis splendide ei. Vis ei tritani alterum petentium, usu sint intellegat ne. Sed in tota nobis prompta, noluisse delicatissimi at ius. <a rel="noreferrer noopener" href="#" target="_blank">Veri placerat</a> mel in, paulo persius omittantur in mei, putant molestie suscipiantur vis ad. Ut mel tollit tacimates suscipiantur, sit audire recusabo philosophia ad, mei amet animal pertinax eu. Mea ipsum offendit appetere eu, justo ubique fierent vis ne. Probo omnesque has ex. Pro no lorem temporibus ullamcorper, no qui democritum consectetuer, habemus pericula eu sit.</p>
                        <figure class="alignleft">
                            <img src="assets/images/amelie-mourichon-wusOJ-2uY6w-unsplash.jpg" alt="">
                            <figcaption>Cu duo antiopam platonem electram</figcaption>
                        </figure>
                        <p>Pro in ridens possit referrentur, ne odio tibique duo. Lorem persecuti scribentur ut est. Eu novum tation persius nec. Sed soluta primis splendide ei. Vis ei tritani alterum petentium, usu sint intellegat ne. Sed in tota nobis prompta, noluisse delicatissimi at ius. <a rel="noreferrer noopener" href="#" target="_blank">Veri placerat</a> mel in, paulo persius omittantur in mei, putant molestie suscipiantur vis ad. Ut mel tollit tacimates suscipiantur, sit audire recusabo philosophia ad, mei amet animal pertinax eu. Mea ipsum offendit appetere eu, justo ubique fierent vis ne. Probo omnesque has ex. Pro no lorem temporibus ullamcorper, no qui democritum consectetuer, habemus pericula eu sit.</p>
                        <p class="has-drop-cap">Has no velit ullamcorper, tale aliquando constituto ei sea, sit iisque facilisi ei. Ad quo possit disputationi. Eam invenire laboramus constituam ex, vel dolore antiopam ex, te pro tota sonet noluisse. Menandri molestiae eum an, pri ut ludus deterruisset delicatissimi. At noster iriure nec, et vix dico graecis.</p>
                        <p>Vel posse suavitate ne. Nam ut enim verear latine, et latine aeterno menandri vel. Fugit habemus posidonium te est, cu his primis tincidunt inciderint. At aeque corpora nam, saepe perfecto at eos. Invidunt reprimique ius an.</p>
                        <blockquote><p>I am enough of an artist to draw freely upon my imagination. Imagination is more important than knowledge. Knowledge is limited. Imagination encircles the world</p></blockquote>
                        <figure class="aligncenter">
                            <img src="assets/images/ilya-pavlov-OqtafYT5kTw-unsplash.jpg" alt="">
                            <figcaption>Align center</figcaption>
                        </figure>
                        <h2>Ordered List</h2>
                        <hr>
                        <p>Vix et labitur epicuri dissentiunt, habemus complectitur an qui, ei qui hinc falli aperiam. Te <a href="#">eos altera</a> eruditi, in cum adipisci sadipscing, modo numquam recusabo cu eum. Augue putant <a href="#">dissentiunt</a> at qui. At pro accusata prodesset vituperatoribus, vel feugait corpora suscipit ut, paulo equidem dissentias ei his.</p>
                        <ul>
                            <li>Aliquam erat volutpat</li>
                            <li>Lacinia scelerisque lacinia quis</li>
                            <li>Consectetuer adipiscing elit</li>
                            <li>Magnis dis parturient montes</li>
                        </ul>
                        <p>Pro in ridens possit referrentur, ne odio tibique duo. Lorem persecuti scribentur ut est. Eu novum tation persius nec. Sed soluta primis splendide ei. Vis ei tritani alterum petentium, usu sint intellegat ne. Sed in tota nobis prompta, noluisse delicatissimi at ius. <a rel="noreferrer noopener" href="#" target="_blank">Veri placerat</a> mel in, paulo persius omittantur in mei, putant molestie suscipiantur vis ad. Ut mel tollit tacimates suscipiantur, sit audire recusabo philosophia ad, mei amet animal pertinax eu. Mea ipsum offendit appetere eu, justo ubique fierent vis ne. Probo omnesque has ex. Pro no lorem temporibus ullamcorper, no qui democritum consectetuer, habemus pericula eu sit.</p>
                        <h2>Ordered List Number</h2>
                        <p>Vix et labitur epicuri dissentiunt, habemus complectitur an qui, ei qui hinc falli aperiam. Te <a href="#">eos altera</a> eruditi, in cum adipisci sadipscing, modo numquam recusabo cu eum. Augue putant <a href="#">dissentiunt</a> at qui. At pro accusata prodesset vituperatoribus, vel feugait corpora suscipit ut, paulo equidem dissentias ei his.</p>
                        <ol>
                            <li>Commodo ligula eget dolor</li>
                            <li>Magnis dis parturient montes</li>
                            <li>Pellentesque eu pretium</li>
                            <li>Donec quam felis</li>
                            <li>Lorem ipsum dolor sit amet</li>
                        </ol>
                        <p>Pro in ridens possit referrentur, ne odio tibique duo. Lorem persecuti scribentur ut est. Eu novum tation persius nec. Sed soluta primis splendide ei. Vis ei tritani alterum petentium, usu sint intellegat ne. Sed in tota nobis prompta, noluisse delicatissimi at ius. <a rel="noreferrer noopener" href="#" target="_blank">Veri placerat</a> mel in, paulo persius omittantur in mei, putant molestie suscipiantur vis ad. Ut mel tollit tacimates suscipiantur, sit audire recusabo philosophia ad, mei amet animal pertinax eu. Mea ipsum offendit appetere eu, justo ubique fierent vis ne. Probo omnesque has ex. Pro no lorem temporibus ullamcorper, no qui democritum consectetuer, habemus pericula eu sit.</p>
                        <p>Cu duo antiopam platonem electram. Dicam tibique an qui, ius ut integre rationibus, ad eos facilisi voluptatibus. Has et impetus labitur, ea duo laoreet sententiae. Hendrerit efficiendi voluptatibus has ea, corrumpit democritum eu sea, eum ex vero veniam. Dicunt ornatus laoreet te eam, vix eu zril epicuri deseruisse. <a href="#">Lorem ipsum</a> dolor sit amet, eu postulant principes quo, an melius scaevola quo. Pri no malorum omittantur, nusquam conclusionemque an sea. Usu amet minim intellegat ut. Ut putant latine petentium sea, sit alii meliore eu.</p>
                    </div>
        
                    <div class="editor-content editor-content__col-two">
                        <p>Cu duo antiopam platonem electram. Dicam tibique an qui, ius ut integre rationibus, ad eos facilisi voluptatibus. Has et impetus labitur, ea duo laoreet sententiae. Hendrerit efficiendi voluptatibus has ea, corrumpit democritum eu sea, eum ex vero veniam. Dicunt ornatus laoreet te eam, vix eu zril epicuri deseruisse. <a href="#">Lorem ipsum</a> dolor sit amet, eu postulant principes quo, an melius scaevola quo. Pri no malorum omittantur, nusquam conclusionemque an sea. Usu amet minim intellegat ut. Ut putant latine petentium sea, sit alii meliore eu.</p>
                        <figure class="alignright">
                            <img src="assets/images/jazmin-quaynor-8ioenvmof-I-unsplash.jpg" alt="">
                            <figcaption>Align right</figcaption>
                        </figure>
                        <p>Pro in ridens possit referrentur, ne odio tibique duo. Lorem persecuti scribentur ut est. Eu novum tation persius nec. Sed soluta primis splendide ei. Vis ei tritani alterum petentium, usu sint intellegat ne. Sed in tota nobis prompta, noluisse delicatissimi at ius. <a rel="noreferrer noopener" href="#" target="_blank">Veri placerat</a> mel in, paulo persius omittantur in mei, putant molestie suscipiantur vis ad. Ut mel tollit tacimates suscipiantur, sit audire recusabo philosophia ad, mei amet animal pertinax eu. Mea ipsum offendit appetere eu, justo ubique fierent vis ne. Probo omnesque has ex. Pro no lorem temporibus ullamcorper, no qui democritum consectetuer, habemus pericula eu sit.</p>
                        <figure class="alignleft">
                            <img src="assets/images/lum3n--RBuQ2PK_L8-unsplash.jpg" alt="">
                            <figcaption>Align left</figcaption>
                        </figure>
                        <p class="has-drop-cap">Has no velit ullamcorper, tale aliquando constituto ei sea, sit iisque facilisi ei. Ad quo possit disputationi. Eam invenire laboramus constituam ex, vel dolore antiopam ex, te pro tota sonet noluisse. Menandri molestiae eum an, pri ut ludus deterruisset delicatissimi. At noster iriure nec, et vix dico graecis.</p>
                        <p>Vel posse suavitate ne. Nam ut enim verear latine, et latine aeterno menandri vel. Fugit habemus posidonium te est, cu his primis tincidunt inciderint. At aeque corpora nam, saepe perfecto at eos. Invidunt reprimique ius an.</p>
                        <blockquote><p>I am enough of an artist to draw freely upon my imagination. Imagination is more important than knowledge. Knowledge is limited. Imagination encircles the world</p></blockquote>
                        <p>Vix et labitur epicuri dissentiunt, habemus complectitur an qui, ei qui hinc falli aperiam. Te <a href="#">eos altera</a> eruditi, in cum adipisci sadipscing, modo numquam recusabo cu eum. Augue putant <a href="#">dissentiunt</a> at qui. At pro accusata prodesset vituperatoribus, vel feugait corpora suscipit ut, paulo equidem dissentias ei his.</p>
                        <p>Pro in ridens possit referrentur, ne odio tibique duo. Lorem persecuti scribentur ut est. Eu novum tation persius nec. Sed soluta primis splendide ei. Vis ei tritani alterum petentium, usu sint intellegat ne. Sed in tota nobis prompta, noluisse delicatissimi at ius. <a rel="noreferrer noopener" href="#" target="_blank">Veri placerat</a> mel in, paulo persius omittantur in mei, putant molestie suscipiantur vis ad. Ut mel tollit tacimates suscipiantur, sit audire recusabo philosophia ad, mei amet animal pertinax eu. Mea ipsum offendit appetere eu, justo ubique fierent vis ne. Probo omnesque has ex. Pro no lorem temporibus ullamcorper, no qui democritum consectetuer, habemus pericula eu sit.</p>
                        <p>Cu duo antiopam platonem electram. Dicam tibique an qui, ius ut integre rationibus, ad eos facilisi voluptatibus. Has et impetus labitur, ea duo laoreet sententiae. Hendrerit efficiendi voluptatibus has ea, corrumpit democritum eu sea, eum ex vero veniam. Dicunt ornatus laoreet te eam, vix eu zril epicuri deseruisse. <a href="#">Lorem ipsum</a> dolor sit amet, eu postulant principes quo, an melius scaevola quo. Pri no malorum omittantur, nusquam conclusionemque an sea. Usu amet minim intellegat ut. Ut putant latine petentium sea, sit alii meliore eu.</p>
                    </div>'
    ),
    '3' => array(
        'id' => '3',
        'title' => 'How to Make Your Tech Last Longer',
        'date' => 'June 2, 2022',
        'image' => 'assets/images/aaron-burden-y02jEX_B0O0-unsplash.jpg',
        'category' => 'Tutorial',
        'content' => '<div class="editor-content editor-content__dropcap">
                        <p>Cu duo antiopam platonem electram. Dicam tibique an qui, ius ut integre rationibus, ad eos facilisi voluptatibus. Has et impetus labitur, ea duo laoreet sententiae. Hendrerit efficiendi voluptatibus has ea, corrumpit democritum eu sea, eum ex vero veniam. Dicunt ornatus laoreet te eam, vix eu zril epicuri deseruisse. <a href="#">Lorem ipsum</a> dolor sit amet, eu postulant principes quo, an melius scaevola quo. Pri no malorum omittantur, nusquam conclusionemque an sea. Usu amet minim intellegat ut. Ut putant latine petentium sea, sit alii meliore eu.</p>
                        <p>Vix et labitur epicuri dissentiunt, habemus complectitur an qui, ei qui hinc falli aperiam. Te <a href="#">eos altera</a> eruditi, in cum adipisci sadipscing, modo numquam recusabo cu eum. Augue putant <a href="#">dissentiunt</a> at qui. At pro accusata prodesset vituperatoribus, vel feugait corpora suscipit ut, paulo equidem dissentias ei his.</p>
                        <p>Pro in ridens possit referrentur, ne odio tibique duo. Lorem persecuti scribentur ut est. Eu novum tation persius nec. Sed soluta primis splendide ei. Vis ei tritani alterum petentium, usu sint intellegat ne. Sed in tota nobis prompta, noluisse delicatissimi at ius. <a rel="noreferrer noopener" href="#" target="_blank">Veri placerat</a> mel in, paulo persius omittantur in mei, putant molestie suscipiantur vis ad. Ut mel tollit tacimates suscipiantur, sit audire recusabo philosophia ad, mei amet animal pertinax eu. Mea ipsum offendit appetere eu, justo ubique fierent vis ne. Probo omnesque has ex. Pro no lorem temporibus ullamcorper, no qui democritum consectetuer, habemus pericula eu sit.</p>
                        <figure class="alignleft">
                            <img src="assets/images/amelie-mourichon-wusOJ-2uY6w-unsplash.jpg" alt="">
                            <figcaption>Cu duo antiopam platonem electram</figcaption>
                        </figure>
                        <p>Pro in ridens possit referrentur, ne odio tibique duo. Lorem persecuti scribentur ut est. Eu novum tation persius nec. Sed soluta primis splendide ei. Vis ei tritani alterum petentium, usu sint intellegat ne. Sed in tota nobis prompta, noluisse delicatissimi at ius. <a rel="noreferrer noopener" href="#" target="_blank">Veri placerat</a> mel in, paulo persius omittantur in mei, putant molestie suscipiantur vis ad. Ut mel tollit tacimates suscipiantur, sit audire recusabo philosophia ad, mei amet animal pertinax eu. Mea ipsum offendit appetere eu, justo ubique fierent vis ne. Probo omnesque has ex. Pro no lorem temporibus ullamcorper, no qui democritum consectetuer, habemus pericula eu sit.</p>
                        <p class="has-drop-cap">Has no velit ullamcorper, tale aliquando constituto ei sea, sit iisque facilisi ei. Ad quo possit disputationi. Eam invenire laboramus constituam ex, vel dolore antiopam ex, te pro tota sonet noluisse. Menandri molestiae eum an, pri ut ludus deterruisset delicatissimi. At noster iriure nec, et vix dico graecis.</p>
                        <p>Vel posse suavitate ne. Nam ut enim verear latine, et latine aeterno menandri vel. Fugit habemus posidonium te est, cu his primis tincidunt inciderint. At aeque corpora nam, saepe perfecto at eos. Invidunt reprimique ius an.</p>
                        <blockquote><p>I am enough of an artist to draw freely upon my imagination. Imagination is more important than knowledge. Knowledge is limited. Imagination encircles the world</p></blockquote>
                        <figure class="aligncenter">
                            <img src="assets/images/ilya-pavlov-OqtafYT5kTw-unsplash.jpg" alt="">
                            <figcaption>Align center</figcaption>
                        </figure>
                        <h2>Ordered List</h2>
                        <hr>
                        <p>Vix et labitur epicuri dissentiunt, habemus complectitur an qui, ei qui hinc falli aperiam. Te <a href="#">eos altera</a> eruditi, in cum adipisci sadipscing, modo numquam recusabo cu eum. Augue putant <a href="#">dissentiunt</a> at qui. At pro accusata prodesset vituperatoribus, vel feugait corpora suscipit ut, paulo equidem dissentias ei his.</p>
                        <ul>
                            <li>Aliquam erat volutpat</li>
                            <li>Lacinia scelerisque lacinia quis</li>
                            <li>Consectetuer adipiscing elit</li>
                            <li>Magnis dis parturient montes</li>
                        </ul>
                        <p>Pro in ridens possit referrentur, ne odio tibique duo. Lorem persecuti scribentur ut est. Eu novum tation persius nec. Sed soluta primis splendide ei. Vis ei tritani alterum petentium, usu sint intellegat ne. Sed in tota nobis prompta, noluisse delicatissimi at ius. <a rel="noreferrer noopener" href="#" target="_blank">Veri placerat</a> mel in, paulo persius omittantur in mei, putant molestie suscipiantur vis ad. Ut mel tollit tacimates suscipiantur, sit audire recusabo philosophia ad, mei amet animal pertinax eu. Mea ipsum offendit appetere eu, justo ubique fierent vis ne. Probo omnesque has ex. Pro no lorem temporibus ullamcorper, no qui democritum consectetuer, habemus pericula eu sit.</p>
                        <h2>Ordered List Number</h2>
                        <p>Vix et labitur epicuri dissentiunt, habemus complectitur an qui, ei qui hinc falli aperiam. Te <a href="#">eos altera</a> eruditi, in cum adipisci sadipscing, modo numquam recusabo cu eum. Augue putant <a href="#">dissentiunt</a> at qui. At pro accusata prodesset vituperatoribus, vel feugait corpora suscipit ut, paulo equidem dissentias ei his.</p>
                        <ol>
                            <li>Commodo ligula eget dolor</li>
                            <li>Magnis dis parturient montes</li>
                            <li>Pellentesque eu pretium</li>
                            <li>Donec quam felis</li>
                            <li>Lorem ipsum dolor sit amet</li>
                        </ol>
                        <p>Pro in ridens possit referrentur, ne odio tibique duo. Lorem persecuti scribentur ut est. Eu novum tation persius nec. Sed soluta primis splendide ei. Vis ei tritani alterum petentium, usu sint intellegat ne. Sed in tota nobis prompta, noluisse delicatissimi at ius. <a rel="noreferrer noopener" href="#" target="_blank">Veri placerat</a> mel in, paulo persius omittantur in mei, putant molestie suscipiantur vis ad. Ut mel tollit tacimates suscipiantur, sit audire recusabo philosophia ad, mei amet animal pertinax eu. Mea ipsum offendit appetere eu, justo ubique fierent vis ne. Probo omnesque has ex. Pro no lorem temporibus ullamcorper, no qui democritum consectetuer, habemus pericula eu sit.</p>
                        <p>Cu duo antiopam platonem electram. Dicam tibique an qui, ius ut integre rationibus, ad eos facilisi voluptatibus. Has et impetus labitur, ea duo laoreet sententiae. Hendrerit efficiendi voluptatibus has ea, corrumpit democritum eu sea, eum ex vero veniam. Dicunt ornatus laoreet te eam, vix eu zril epicuri deseruisse. <a href="#">Lorem ipsum</a> dolor sit amet, eu postulant principes quo, an melius scaevola quo. Pri no malorum omittantur, nusquam conclusionemque an sea. Usu amet minim intellegat ut. Ut putant latine petentium sea, sit alii meliore eu.</p>
                    </div>

                    <div class="editor-content editor-content__col-two">
                        <p>Cu duo antiopam platonem electram. Dicam tibique an qui, ius ut integre rationibus, ad eos facilisi voluptatibus. Has et impetus labitur, ea duo laoreet sententiae. Hendrerit efficiendi voluptatibus has ea, corrumpit democritum eu sea, eum ex vero veniam. Dicunt ornatus laoreet te eam, vix eu zril epicuri deseruisse. <a href="#">Lorem ipsum</a> dolor sit amet, eu postulant principes quo, an melius scaevola quo. Pri no malorum omittantur, nusquam conclusionemque an sea. Usu amet minim intellegat ut. Ut putant latine petentium sea, sit alii meliore eu.</p>
                        <figure class="alignright">
                            <img src="assets/images/jazmin-quaynor-8ioenvmof-I-unsplash.jpg" alt="">
                            <figcaption>Align right</figcaption>
                        </figure>
                        <p>Pro in ridens possit referrentur, ne odio tibique duo. Lorem persecuti scribentur ut est. Eu novum tation persius nec. Sed soluta primis splendide ei. Vis ei tritani alterum petentium, usu sint intellegat ne. Sed in tota nobis prompta, noluisse delicatissimi at ius. <a rel="noreferrer noopener" href="#" target="_blank">Veri placerat</a> mel in, paulo persius omittantur in mei, putant molestie suscipiantur vis ad. Ut mel tollit tacimates suscipiantur, sit audire recusabo philosophia ad, mei amet animal pertinax eu. Mea ipsum offendit appetere eu, justo ubique fierent vis ne. Probo omnesque has ex. Pro no lorem temporibus ullamcorper, no qui democritum consectetuer, habemus pericula eu sit.</p>
                        <figure class="alignleft">
                            <img src="assets/images/lum3n--RBuQ2PK_L8-unsplash.jpg" alt="">
                            <figcaption>Align left</figcaption>
                        </figure>
                        <p class="has-drop-cap">Has no velit ullamcorper, tale aliquando constituto ei sea, sit iisque facilisi ei. Ad quo possit disputationi. Eam invenire laboramus constituam ex, vel dolore antiopam ex, te pro tota sonet noluisse. Menandri molestiae eum an, pri ut ludus deterruisset delicatissimi. At noster iriure nec, et vix dico graecis.</p>
                        <p>Vel posse suavitate ne. Nam ut enim verear latine, et latine aeterno menandri vel. Fugit habemus posidonium te est, cu his primis tincidunt inciderint. At aeque corpora nam, saepe perfecto at eos. Invidunt reprimique ius an.</p>
                        <blockquote><p>I am enough of an artist to draw freely upon my imagination. Imagination is more important than knowledge. Knowledge is limited. Imagination encircles the world</p></blockquote>
                        <p>Vix et labitur epicuri dissentiunt, habemus complectitur an qui, ei qui hinc falli aperiam. Te <a href="#">eos altera</a> eruditi, in cum adipisci sadipscing, modo numquam recusabo cu eum. Augue putant <a href="#">dissentiunt</a> at qui. At pro accusata prodesset vituperatoribus, vel feugait corpora suscipit ut, paulo equidem dissentias ei his.</p>
                        <p>Pro in ridens possit referrentur, ne odio tibique duo. Lorem persecuti scribentur ut est. Eu novum tation persius nec. Sed soluta primis splendide ei. Vis ei tritani alterum petentium, usu sint intellegat ne. Sed in tota nobis prompta, noluisse delicatissimi at ius. <a rel="noreferrer noopener" href="#" target="_blank">Veri placerat</a> mel in, paulo persius omittantur in mei, putant molestie suscipiantur vis ad. Ut mel tollit tacimates suscipiantur, sit audire recusabo philosophia ad, mei amet animal pertinax eu. Mea ipsum offendit appetere eu, justo ubique fierent vis ne. Probo omnesque has ex. Pro no lorem temporibus ullamcorper, no qui democritum consectetuer, habemus pericula eu sit.</p>
                        <p>Cu duo antiopam platonem electram. Dicam tibique an qui, ius ut integre rationibus, ad eos facilisi voluptatibus. Has et impetus labitur, ea duo laoreet sententiae. Hendrerit efficiendi voluptatibus has ea, corrumpit democritum eu sea, eum ex vero veniam. Dicunt ornatus laoreet te eam, vix eu zril epicuri deseruisse. <a href="#">Lorem ipsum</a> dolor sit amet, eu postulant principes quo, an melius scaevola quo. Pri no malorum omittantur, nusquam conclusionemque an sea. Usu amet minim intellegat ut. Ut putant latine petentium sea, sit alii meliore eu.</p>
                    </div>'
    )
);

// if post empty return 0
if(empty($post[$data['id']])) {
    echo json_encode(array('code' => 0));
    return;
}

// view post
$post_detail = $post[$data['id']];
$view = '<section class="single-page mb-5">
            <div class="col-12">
                <figure class="ratio ratio-21x9 bg-cover" style="background-image: url('.$post_detail['image'].')"></figure>
            </div>
            <div class="col-10 col-md-8 offset-1 offset-md-2">
                <div class="single-post">
                        <h2 class="single-post__title">'.$post_detail['title'].'</h2>
                        <div class="entry mt-0 mb-4">
                            <span class="entry__date">'.$post_detail['date'].'</span>
                            <span class="entry__category"><a>'.$post_detail['category'].'</a></span>
                        </div>
                        '.$post_detail['content'].'
                        <!--- start component tag & share --->
                        <div class="single-post__component d-none">
                            <div class="post-tags">
                                <div class="post-tags-inner">
                                    <a rel="tag" href="#"><i class="fa fa-search" aria-hidden="true"></i> Love</a>
                                    <a rel="tag" href="#"><i class="fa fa-search" aria-hidden="true"></i> Fashion</a>
                                    <a rel="tag" href="#"><i class="fa fa-search" aria-hidden="true"></i> Lifestyle</a>
                                    <a rel="tag" href="#"><i class="fa fa-search" aria-hidden="true"></i> Politic</a>
                                </div>
                            </div>
                            <div class="post-share">
                                <label>Share post: </label>
                                <ul>
                                    <li class="facebook"><a href=""><i class="fa fa-facebook"></i></a></li>
                                    <li class="twitter"><a href=""><i class="fa fa-twitter"></i></a></li>
                                    <li class="google-plus"><a href=""><i class="fa fa-google-plus"></i></a></li>
                                    <li class="instagram"><a href=""><i class="fa fa-instagram"></i></a></li>
                                </ul>
                            </div>
                        </div>
                        <!--- end component tag & share --->

                        <!--- start component author --->
                        <div class="post-author d-none">
                            <figure>
                                <a href="#"><img src="assets/images/omid-armin-wrXziQTIFUY-unsplash.jpg"></a>
                            </figure>
                            <div class="post-author__info">
                                <h3 class="post-author__name"><a href="#">Ms Jane</a></h3>
                                <div class="post-author__content">Cu duo antiopam platonem electram. Dicam tibique an qui, ius ut integre rationibus, ad eos facilisi voluptatibus. Has et impetus labitur,</div>
                                <ul class="post-author__social">
                                    <li><a href=""><i class="fa fa-facebook"></i></a></li>
                                    <li><a href=""><i class="fa fa-twitter"></i></a></li>
                                    <li><a href=""><i class="fa fa-google-plus"></i></a></li>
                                </ul>
                            </div>
                        </div>
                        <!--- end component author --->

                        <!--- start component next & prev --->
                        <div class="single-post__nav d-none">
                            <div class="single-post__nav--prev">
                                <a href="#">
                                    <span>Prev post</span>
                                    <h3 class="single-post__nav--title">How to Get Around Thailand on the Cheap in 2020</h3>
                                </a>
                            </div>
                            <div class="single-post__nav--next">
                                <a href="#">
                                    <span>Next post</span>
                                    <h3 class="single-post__nav--title">The Best Tour Companies in Italy</h3>
                                </a>
                            </div>
                        </div>
                        <!--- end component next & prev --->

                        <!--- start component related --->
                        <div class="related-post d-none">
                            <div class="related-post__headline"><span>Related Post</span></div>
                            <div class="related-post__list">
                                <div class="related-post__item">
                                    <a href="#">
                                        <figure class="lazy related-post__image" data-src="assets/images/corinne-kutz-tMI2_-r5Nfo-unsplash.jpg"></figure>
                                    </a>
                                    <div class="entry mt-0 mb-2">
                                        <span class="entry__date">June 2, 2020</span>
                                        <span class="entry__category"><a href="category.html">Sport</a></span>
                                    </div>
                                    <h3 class="related-post__title"><a href="#">Analysis: Strategy could work – but probably won’t</a></h3>
                                </div>
                                <div class="related-post__item">
                                    <a href="#">
                                        <figure class="lazy related-post__image" data-src="assets/images/domenico-loia-hGV2TfOh0ns-unsplash.jpg"></figure>
                                    </a>
                                    <div class="entry mt-0 mb-2">
                                        <span class="entry__date">June 2, 2020</span>
                                        <span class="entry__category"><a href="category.html">Sport</a></span>
                                    </div>
                                    <h3 class="related-post__title"><a href="#">The Best Tour Companies in Italy</a></h3>
                                </div>
                                <div class="related-post__item">
                                    <a href="#">
                                        <figure class="lazy related-post__image" data-src="assets/images/leone-venter-pVt9j3iWtPM-unsplash.jpg"></figure>
                                    </a>
                                    <div class="entry mt-0 mb-2">
                                        <span class="entry__date">June 2, 2020</span>
                                        <span class="entry__category"><a href="category.html">Sport</a></span>
                                    </div>
                                    <h3 class="related-post__title"><a href="#">How to Get Around Thailand on the Cheap in 2020</a></h3>
                                </div>
                            </div>
                        </div>
                        <!--- end component related --->

                        <!--- start component comment --->
                        <div class="single-comment d-none">
                            <section id="comments">
                                <h4 class="single-comment-title">Comments</h4>
                                <div class="comments-inner clr">
                                    <div class="comments-title"> <p>There are 3 comments for this article</p></div>
                                    <!-- start comment list -->
                                    <ol class="commentlist">
                                        <li id="li-comment-4">
                                            <article class="comment even thread-even depth-1 clr" id="comment-4">
                                                <div class="comment-author vcard"> <img width="60" height="60" src="assets/images/omid-armin-DRB6i_jIbww-unsplash.jpg" alt=""></div>
                                                <div class="comment-details clr ">
                                                    <header class="comment-meta"> <strong class="fn"> Steven Jobs </strong> <span class="comment-date">July 4, 2017 7:25 am </span></header>
                                                    <div class="comment-content entry clr">
                                                        <p>dived wound factual legitimately delightful goodness fit rat some lopsidedly far when.</p>
                                                    </div>
                                                    <div class="reply comment-reply-link-div"> <a aria-label="Reply to spadmin" href="#respond" class="comment-reply-link" rel="nofollow">Reply</a></div>
                                                </div>
                                            </article>
                                            <ul class="children">
                                                <li id="li-comment-6">
                                                    <article class="comment odd alt depth-2 clr" id="comment-6">
                                                        <div class="comment-author vcard"><img width="60" height="60" src="assets/images/mehrab-zahedbeigi-Wa3v4Fd8xBg-unsplash.jpg" alt=""></div>
                                                        <div class="comment-details clr ">
                                                            <header class="comment-meta"> <strong class="fn"> Jim Calist </strong> <span class="comment-date">July 16, 2017 1:29 am </span></header>
                                                            <div class="comment-content entry clr">
                                                                <p>Slung alongside jeepers hypnotic legitimately some iguana this agreeably triumphant pointedly far</p>
                                                            </div>
                                                            <div class="reply comment-reply-link-div"><a aria-label="Reply to spadmin" href="#respond" class="comment-reply-link" rel="nofollow">Reply</a></div>
                                                        </div>
                                                    </article>
                                                </li>
                                            </ul>
                                        </li>
                                        <li id="li-comment-5">
                                            <article class="comment even thread-odd thread-alt depth-1 clr" id="comment-5">
                                                <div class="comment-author vcard"> <img width="60" height="60" src="assets/images/omid-armin-wrXziQTIFUY-unsplash.jpg" alt=""></div>
                                                <div class="comment-details clr ">
                                                    <header class="comment-meta"> <strong class="fn"> Steven Jobs </strong> <span class="comment-date">July 4, 2017 7:25 am </span></header>
                                                    <div class="comment-content entry clr">
                                                        <p>jeepers unscrupulous anteater attentive noiseless put less greyhound prior stiff ferret unbearably cracked oh.</p>
                                                    </div>
                                                    <div class="reply comment-reply-link-div"><a aria-label="Reply to spadmin" href="#respond" class="comment-reply-link" rel="nofollow">Reply</a></div>
                                                </div>
                                            </article>
                                        </li>
                                        <li id="li-comment-85">
                                            <article class="comment byuser comment-author-spadmin bypostauthor odd alt thread-even depth-1 clr" id="comment-85">
                                                <div class="comment-author vcard"><img width="60" height="60" src="assets/images/mehrab-zahedbeigi-Wa3v4Fd8xBg-unsplash.jpg" alt=""></div>
                                                <div class="comment-details clr ">
                                                    <header class="comment-meta"> <strong class="fn"> Steven Jobs <span class="author-badge"></span> </strong> <span class="comment-date">May 10, 2018 2:41 am </span></header>
                                                    <div class="comment-content entry clr">
                                                        <p>So sparing more goose caribou wailed went conveniently burned the the the and that save that adroit gosh and sparing armadillo grew some overtook that magnificently that</p>
                                                    </div>
                                                    <div class="reply comment-reply-link-div"><a aria-label="Reply to spadmin" href="#respond" class="comment-reply-link" rel="nofollow">Reply</a></div>
                                                </div>
                                            </article>
                                        </li>
                                        <li id="li-comment-86">
                                            <article class="comment byuser comment-author-spadmin bypostauthor even thread-odd thread-alt depth-1 clr" id="comment-86">
                                                <div class="comment-author vcard"><img width="60" height="60" src="assets/images/omid-armin-DRB6i_jIbww-unsplash.jpg" alt=""></div>
                                                <div class="comment-details clr ">
                                                    <header class="comment-meta"> <strong class="fn"> Steven Jobs <span class="author-badge"></span> </strong> <span class="comment-date">May 10, 2018 2:42 am </span></header>
                                                    <div class="comment-content entry clr">
                                                        <p>Circuitous gull and messily squirrel on that banally assenting nobly some much rakishly goodness that the darn abject hello left because unaccountably spluttered unlike a aurally since contritely thanks</p>
                                                    </div>
                                                    <div class="reply comment-reply-link-div"><a aria-label="Reply to spadmin" href="#respond" class="comment-reply-link" rel="nofollow">Reply</a></div>
                                                </div>
                                            </article>
                                        </li>
                                    </ol>
                                    <!-- end comment list -->

                                    <!-- start comment form -->
                                    <div class="comment-respond" id="respond">
                                        <h3 class="comment-reply-title" id="reply-title">Leave a Reply</h3>
                                        <form novalidate="" class="comment-form" id="commentform" method="post" action="">
                                            <div class="comment-form__row">
                                                <div class="comment-form-author ">
                                                    <input type="text" size="30" value="" placeholder="Your name *" name="author" id="author">
                                                </div>
                                                <div class="comment-form-email ">
                                                    <input type="email" size="30" value="" placeholder="Email *" name="email" id="email">
                                                </div>
                                            </div>
                                            <div class="comment-form__row">
                                                <textarea aria-required="true" placeholder="Your Comment" rows="8" cols="45" name="comment" id="comment"></textarea>
                                            </div>
                                            <div class="form-submit">
                                                <input type="submit" value="Post Comment" class="submit" id="submit" name="submit">
                                                <input type="hidden" id="comment_post_ID" value="80" name="comment_post_ID">
                                                <input type="hidden" value="0" id="comment_parent" name="comment_parent">
                                            </div>
                                        </form>
                                    </div>
                                    <!-- end comment form -->

                                </div>
                            </section>
                        </div>
                        <!--- end component comment --->
                    </div>
            </div>
    </section>';

echo json_encode(array('code' => 1, 'view' => $view));
return;